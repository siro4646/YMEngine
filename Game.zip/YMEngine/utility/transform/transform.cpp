#include "application/application.h"

//void ym::Transform::Rotate(Vector3 rot)
//{
//	auto delta = Application::Instance()->GetDeltaTime();
//	Rotation += rot * delta;
//}
