#include "logSystem.h"

namespace ym
{
    void LogSystem::AddLog(const std::string &message) {
        if (aggregateMode_) {
            auto it = logMap_.find(message);
            if (it != logMap_.end()) {
                logs_[it->second].count++;
            }
            else {
                logs_.push_back({ message, 1 });
                logMap_[message] = logs_.size() - 1;
            }
        }
        else {
            logs_.push_back({ message, 1 }); // �J�E���g�͏��1
        }

        scrollToBottom_ = true;
    }


    void LogSystem::Clear() {
        logs_.clear();
        logMap_.clear();
    }


    void LogSystem::Draw(const char *title) {
        ImGui::Begin(title);

        if (ImGui::Button("Clear")) {
            Clear();
        }

        ImGui::SameLine();
        if (ImGui::Checkbox("Aggregate", &aggregateMode_)) {
            Rebuild(); // �W��/��W�񃂁[�h�ؑ֎��ɍč\�z
        }

        ImGui::Separator();

        ImGui::BeginChild("LogScroll", ImVec2(0, 0), false, ImGuiWindowFlags_HorizontalScrollbar);
        for (const auto &entry : logs_) {
            if (entry.count > 1) {
                ImGui::Text("[%d] %s", entry.count, entry.message.c_str());
            }
            else {
                ImGui::TextUnformatted(entry.message.c_str());
            }
        }

        if (scrollToBottom_) {
            ImGui::SetScrollHereY(1.0f);
            scrollToBottom_ = false;
        }

        ImGui::EndChild();
        ImGui::End();
    }
    void LogSystem::Rebuild()
    {
        std::vector<std::string> rawLogs;

        for (const auto &entry : logs_) {
            for (int i = 0; i < entry.count; ++i) {
                rawLogs.push_back(entry.message);
            }
        }

        logs_.clear();
        logMap_.clear();

        for (const auto &line : rawLogs) {
            AddLog(line);
        }
    }
}
