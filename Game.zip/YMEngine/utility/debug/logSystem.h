#pragma once
#include "system/singleton/singleton.h"
namespace ym
{
    struct LogEntry {
        std::string message;
        int count = 1;
    };

	class LogSystem :public Singleton<LogSystem>
    {
    public:
        void AddLog(const std::string &message);
        void Clear();
        void Draw(const char *title = "Console");
    private:
        void Rebuild();
        std::vector<LogEntry> logs_;  // �\���p
        std::unordered_map<std::string, size_t> logMap_; // ���ꃍ�O�̌����p
        bool aggregateMode_ = true;   // �W��\�����[�h
        bool scrollToBottom_ = false;
    };
}