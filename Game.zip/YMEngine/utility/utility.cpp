namespace ym
{
	Random GlobalRandom{};
}