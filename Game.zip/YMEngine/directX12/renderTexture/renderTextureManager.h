#pragma once

#include "renderTexture/renderTexture.h"

namespace ym
{
	//class RenderTexture;
	/*class RenderTextureManager
	{};*/

}