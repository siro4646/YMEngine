#include "gameObjectManager.h"
#include "gameObject.h"

#include <algorithm>
#include <mutex>
#include <execution> // ������s�|���V�[�𗘗p����ꍇ
#include <thread>

#include "../system/threadPool/threadPool.h"

#include "gameFrameWork/camera/cameraManager.h"
#include "gameFrameWork/camera/camera.h"
#include "gameFrameWork/light/pointLight.h"

namespace ym
{

	GameObjectManager::GameObjectManager()
	{

	}

	GameObjectManager::~GameObjectManager()
	{

	}

	void GameObjectManager::Init()
	{
	}


	//void GameObjectManager::FixedUpdate() {

	//	//std::vector<std::shared_ptr<Object>> objectsToDelete;
	//	//std::mutex deleteMutex;
	//	//std::mutex fixedUpdateMutex;

	//	//// ����� FixedUpdate �����s
	//	//std::for_each(std::execution::par, gameObjects_.begin(), gameObjects_.end(), [&](auto &gameObject) {
	//	//	if (gameObject->type == Object::Type::Delete) {
	//	//		std::lock_guard<std::mutex> lock(deleteMutex); // �폜���X�g�ւ̃A�N�Z�X��ی�
	//	//		objectsToDelete.push_back(gameObject);
	//	//	}
	//	//	else {
	//	//		std::lock_guard<std::mutex> lock(fixedUpdateMutex);// FixedUpdate�̃A�N�Z�X��ی�
	//	//		gameObject->FixedUpdate();
	//	//	}
	//	//	});

	//	//// �폜�����̓V���O���X���b�h�Ŏ��s
	//	//for (auto &gameObject : objectsToDelete) {
	//	//	gameObject->Uninit();
	//	//	std::lock_guard<std::mutex> lock(deleteMutex);
	//	//	gameObjects_.erase(std::remove(gameObjects_.begin(), gameObjects_.end(), gameObject), gameObjects_.end());
	//	//}

	//	

	//	std::vector<std::shared_ptr<Object>> objectsToDelete;
	//	
	//	for (auto obj : gameObjects_)
	//	{
	//		if (!obj)continue;

	//		if (obj->type == Object::Type::Delete)
	//		{
	//			objectsToDelete.push_back(obj);
	//		}
	//		else
	//		{
	//			obj->FixedUpdate();
	//		}
	//	}

	//	for (auto deleteObj : objectsToDelete)
	//	{
	//		//��������

	//		deleteObj->Uninit();

	//		gameObjects_.erase(std::remove(gameObjects_.begin(), gameObjects_.end(), deleteObj), gameObjects_.end());

	//	}

	//	//for (auto deleteObj : objectsToDelete)
	//	//{
	//	//	//��������

	//	//}
	//	
	//}

	void GameObjectManager::FixedUpdate() {
		std::vector<std::shared_ptr<Object>> objectsToDelete;
		std::mutex deleteMutex;

		std::vector<std::future<void>> futures;
		for (auto obj : gameObjects_)
		{
			if (!obj) continue;

			auto future = ThreadPool::Instance().enqueue([&, obj]() {
				if (obj->type == Object::Type::Delete)
				{
					std::lock_guard<std::mutex> lock(deleteMutex);
					objectsToDelete.push_back(obj);
				}
				else
				{
					obj->FixedUpdate();
				}
				});

			futures.push_back(std::move(future));
		}

		for (auto &future : futures)
		{
			future.get();
		}

		for (auto deleteObj : objectsToDelete)
		{
			deleteObj->Uninit();

			gameObjects_.erase(std::remove(gameObjects_.begin(), gameObjects_.end(), deleteObj), gameObjects_.end());
		}
	}



	//void GameObjectManager::Update() {
	//	//std::vector<std::shared_ptr<Object>> objectsToDelete;
	//	//std::mutex deleteMutex;
	//	//std::mutex updateMutex;

	//	////addObjects_�̒��g��gameObjects_�Ɉڂ�

	//	//for (auto obj : addObjects_)
	//	//{
	//	//	gameObjects_.push_back(obj);
	//	//	//obj->Init();
	//	//}

	//	//// ����� Update �����s
	//	//std::for_each(std::execution::par, gameObjects_.begin(), gameObjects_.end(), [&](auto &gameObject) {
	//	//	if (gameObject->type == Object::Type::Delete) {
	//	//		std::lock_guard<std::mutex> lock(deleteMutex); // �폜���X�g�ւ̃A�N�Z�X��ی�
	//	//		objectsToDelete.push_back(gameObject);
	//	//	}
	//	//	else {
	//	//		std::lock_guard<std::mutex> lock(updateMutex);// Update�̃A�N�Z�X��ی�
	//	//		gameObject->Update();
	//	//	}
	//	//	});

	//	//// �폜�����̓V���O���X���b�h�Ŏ��s
	//	//for (auto &gameObject : objectsToDelete) {
	//	//	gameObject->Uninit();
	//	//	std::lock_guard<std::mutex> lock(deleteMutex);
	//	//	gameObjects_.erase(std::remove(gameObjects_.begin(), gameObjects_.end(), gameObject), gameObjects_.end());
	//	//}

	//	//addObjects_�̒��g��gameObjects_�Ɉڂ�

	//	for (auto obj : addObjects_)
	//	{
	//		gameObjects_.push_back(obj);
	//		//obj->Init();
	//	}
	//	addObjects_.clear();
	//	std::vector<std::shared_ptr<Object>> objectsToDelete;

	//	for (auto obj : gameObjects_)
	//	{
	//		if (!obj)continue;
	//		if (obj->type == Object::Type::Delete)
	//		{
	//			objectsToDelete.push_back(obj);
	//		}
	//		else
	//		{
	//			obj->Update();
	//		}
	//	}

	//	for (auto deleteObj : objectsToDelete)
	//	{
	//		//��������

	//		deleteObj->Uninit();

	//		gameObjects_.erase(std::remove(gameObjects_.begin(), gameObjects_.end(), deleteObj), gameObjects_.end());

	//	}


	//	//for (auto deleteObj : objectsToDelete)
	//	//{
	//	//	//��������

	//	//}
	//}

	void GameObjectManager::Update() {
		// AddObjects�̈ړ�
		for (auto obj : addObjects_)
		{
			gameObjects_.push_back(obj);
		}
		addObjects_.clear();

		std::vector<std::shared_ptr<Object>> objectsToDelete;
		std::mutex deleteMutex;

		// ThreadPool �Ƀ^�X�N�𓊂���
		std::vector<std::future<void>> futures;
		for (auto obj : gameObjects_)
		{
			if (!obj) continue;

			auto future = ThreadPool::Instance().enqueue([&, obj]() {
				if (obj->type == Object::Type::Delete)
				{
					std::lock_guard<std::mutex> lock(deleteMutex);
					objectsToDelete.push_back(obj);
				}
				else
				{
					obj->Update();
				}
				});

			futures.push_back(std::move(future));
		}

		// �S�^�X�N�����҂�
		for (auto &future : futures)
		{
			future.get();
		}

		// �폜�����i���C���X���b�h�ōs���j
		for (auto deleteObj : objectsToDelete)
		{
			deleteObj->Uninit();

			gameObjects_.erase(std::remove(gameObjects_.begin(), gameObjects_.end(), deleteObj), gameObjects_.end());
		}
	}


	void GameObjectManager::Draw()
	{
		ImGui::Begin(u8"�V�[���̑���Ə��");
		ImGui::Text("YMEngine TestScene");
		//�}�E�X�J�[�\���̈ʒu���擾
		auto mousePos = ImGui::GetMousePos();
		ImGui::Text(u8"�}�E�X�J�[�\���̈ʒu: %.1f, %.1f", mousePos.x, mousePos.y);
		auto mainCamera = CameraManager::Instance().GetMainCamera();
		ImGui::Text(u8"�J�����̈ʒu %f %f %f", mainCamera->GetEye().x, mainCamera->GetEye().y, mainCamera->GetEye().z);
		ImGui::Text("Framerate(avg) %.3f ms/frame (%.If FPS)",
			1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
		ImGui::Text(u8"�g�p�X���b�h��/�S�̂̃X���b�h��: %d / %d", ym::ThreadPool::Instance().GetBusyThreadCount(), ym::ThreadPool::Instance().GetThreadCount());
		ImGui::Separator(); // ��؂��
		ImGui::Text("PointLight");
		if (ImGui::Button("Add PointLight"))
		{
			auto mainCamera = CameraManager::Instance().GetMainCamera();
			auto obj = AddGameObject(std::make_shared<ym::PointLight>());
			obj->localTransform.Position.x = mainCamera->GetEye().x;
			obj->localTransform.Position.y = mainCamera->GetEye().y;
			obj->localTransform.Position.z = mainCamera->GetEye().z;
		}
		ImGui::Separator(); // ��؂��
		auto lights = FindGameObjects<ym::PointLight>();

		// 4. ���ꂼ��̃��C�g�ɑ΂��� UI ���i���쐬
		for (int i = 0; i < (int)lights.size(); ++i)
		{
			auto &light = lights[i];
			ImGui::PushID(i); // �d�����Ȃ�����ID��ݒ�

			// 4-2. ���C�g�p�����[�^�̒���
			auto &d = light->GetData();  // ��قǗp�ӂ����A�N�Z�T�œ����f�[�^�����o��

			// �ʒu (X,Y,Z) ���X���C�_�[�ő���
			float position[3];
			position[0] = d.position.x;
			position[1] = d.position.y;
			position[2] = d.position.z;
			ImGui::SliderFloat3("Position", position, -5.0f, 5.0f);
			// �ʒu���X�V

			d.position.x = position[0];
			d.position.y = position[1];
			d.position.z = position[2];
			light->localTransform.Position.x = d.position.x; // Transform �ɔ��f
			light->localTransform.Position.y = d.position.y;
			light->localTransform.Position.z = d.position.z;
			// �F (RGB) ���J���[�s�b�J�[�ő���
			// ColorEdit3 �� ImGui �̑g�ݍ��݂ŁAfloat[3] �� 0.0�`1.0 �ň����܂�
			ImGui::ColorEdit3("Color", &d.color.x);
			// ���x�Ɖe���͈�
			ImGui::SliderFloat("Intensity", &d.intensity, 0.0f, 100.0f);
			ImGui::SliderFloat("Radius", &d.radius, 0.0f, 10.0f);

			ImGui::PopID();
			ImGui::Separator();
		}
		ImGui::End();

		std::mutex drawMutex;

		for (auto obj : gameObjects_)
		{
			if (!obj) continue;
			obj->DrawImgui();
		}

		// ����� Draw �����s
		std::for_each(std::execution::par, gameObjects_.begin(), gameObjects_.end(), [&](auto &gameObject) {
			if (gameObject->type != Object::Type::Delete) {
				std::lock_guard<std::mutex> lock(drawMutex);// Update�̃A�N�Z�X��ی�
				gameObject->Draw();				
			}
			});

		/*for (auto &gameObject : gameObjects_)
		{
			if (gameObject->type != Object::Type::Delete)
			gameObject->Draw();
		}*/
	}

	void GameObjectManager::Uninit()
	{
		gameObjects_.clear();
		addObjects_.clear();


	}

	std::shared_ptr<Object> GameObjectManager::AddGameObject(std::shared_ptr<Object> gameObject, Object *const parent)
	{		
		if (parent != nullptr)
		{
			parent->AddChild(gameObject);
		}
		addObjects_.push_back(gameObject);
		gameObject->objectManager = this;
		gameObject->Init();
		return gameObject;
	}

	void GameObjectManager::RemoveGameObject(std::shared_ptr<Object> gameObject)
	{
	}

	std::vector<std::shared_ptr<Object>> GameObjectManager::FindGameObjects(const std::string &name)
	{
		
		ym::ConsoleLog("FindGameObjects�֐����Ă΂�܂���:%s",name);

		// ��v����I�u�W�F�N�g���i�[����z��
		std::vector<std::shared_ptr<Object>> objects;

		// gameObjects_���󂩊m�F
		if (gameObjects_.empty()) {
			ym::ConsoleLog("gameObjects_�͋�ł��B");
			return objects;
		}

		// �e�I�u�W�F�N�g���m�F
		for (const auto &gameObject : gameObjects_) {
			if (!gameObject) { // null�`�F�b�N
				ym::ConsoleLog("�x��: gameObjects_��null�̃I�u�W�F�N�g������܂��B");
				continue;
			}

			if (gameObject->name == name) { // ���O�̔�r
				objects.push_back(gameObject);
			}
		}

		ym::ConsoleLog("��v����I�u�W�F�N�g��:&s",std::to_string(objects.size()));
		return objects;
	}

}