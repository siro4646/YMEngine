#include "meshLoader.h"
#include "gameFrameWork/components/mesh/instance/meshInstance.h"
#include "gameObject/gameObject.h"
#include "gameFrameWork/components/mesh/filter/meshFilter.h"
#include "gameFrameWork/components/mesh/renderer/meshRenderer.h"

namespace ym::mesh {
	// �����o�ϐ��̏�����
	float MeshLoader::minX = FLT_MAX;
	float MeshLoader::minY = FLT_MAX;
	float MeshLoader::minZ = FLT_MAX;
	float MeshLoader::maxX = -FLT_MAX;
	float MeshLoader::maxY = -FLT_MAX;
	float MeshLoader::maxZ = -FLT_MAX;

   /* std::shared_ptr<MeshInstance> MeshLoader::LoadMesh(const std::string &filePath) {
        if (filePath.empty()) return nullptr;
        minX = FLT_MAX, minY = FLT_MAX, minZ = FLT_MAX;
        maxX = -FLT_MAX, maxY = -FLT_MAX, maxZ = -FLT_MAX;

        Mesh combinedMesh;
        Assimp::Importer importer;

        int flag = 0;
        flag |= aiProcess_Triangulate;
        flag |= aiProcess_PreTransformVertices;
        flag |= aiProcess_CalcTangentSpace;
        flag |= aiProcess_GenSmoothNormals;
        flag |= aiProcess_GenUVCoords;
        flag |= aiProcess_RemoveRedundantMaterials;
        flag |= aiProcess_OptimizeMeshes;

        const aiScene *scene = importer.ReadFile(filePath, flag);
        if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode) return nullptr;

        u32 indexOffset = 0;
        for (u32 i = 0; i < scene->mNumMeshes; ++i) {
            const aiMesh *assimpMesh = scene->mMeshes[i];
            Mesh tempMesh;
            LoadMesh(tempMesh, assimpMesh, false, false);

            if (!tempMesh.Vertices.empty()) {
                combinedMesh.Vertices.insert(combinedMesh.Vertices.end(),
                    tempMesh.Vertices.begin(), tempMesh.Vertices.end());

                for (auto idx : tempMesh.Indices) {
                    combinedMesh.Indices.push_back(idx + indexOffset);
                }

                indexOffset += static_cast<u32>(tempMesh.Vertices.size());
            }
        }

        NormalizeScale(combinedMesh);
        return std::make_shared<MeshInstance>(combinedMesh);
    }*/

    void MeshLoader::LoadMeshHierarchy(std::shared_ptr<Object> parent, const std::string &filePath) {
        if (!parent || filePath.empty()) return;

        minX = FLT_MAX, minY = FLT_MAX, minZ = FLT_MAX;
        maxX = -FLT_MAX, maxY = -FLT_MAX, maxZ = -FLT_MAX;

        Assimp::Importer importer;
        unsigned int flags = aiProcess_Triangulate | aiProcess_PreTransformVertices |
            aiProcess_CalcTangentSpace | aiProcess_GenSmoothNormals |
            aiProcess_GenUVCoords | aiProcess_RemoveRedundantMaterials |
            aiProcess_OptimizeMeshes;

        const aiScene *scene = importer.ReadFile(filePath, flags);
        if (!scene || !scene->HasMeshes()) return;
		vector<Mesh> meshes;

        for (unsigned int i = 0; i < scene->mNumMeshes; ++i) {
            Mesh mesh;
            LoadMesh(mesh, scene->mMeshes[i], false, false);  
			meshes.push_back(mesh);
        }
        if (meshes.size() == 1)
        {
			NormalizeScale(meshes[0]);
			auto meshInstance = std::make_shared<MeshInstance>(meshes[0]);
			auto meshFilter = parent->AddComponent<mesh::MeshFilter>();
			meshFilter->SetMeshInstance(meshInstance);
			parent->AddComponent<mesh::MeshRenderer>();
			return;
        }

        for (size_t i = 0; i < meshes.size(); ++i) {
            auto child = std::make_shared<Object>();
            child->name = "SubMesh_" + std::to_string(i);
            parent->AddChild(child);
			NormalizeScale(meshes[i]);
            auto meshInstance = std::make_shared<MeshInstance>(meshes[i]);
            auto meshFilter = child->AddComponent<mesh::MeshFilter>();
            meshFilter->SetMeshInstance(meshInstance);
            child->AddComponent<mesh::MeshRenderer>();
        }
    }

    void MeshLoader::LoadMesh(Mesh &dst, const aiMesh *src, bool inverseU, bool inverseV) {
        aiVector3D zero3D(0, 0, 0);
        aiColor4D zeroColor(0.0f, 0.0f, 0.0f, 0.0f);

        dst.Vertices.resize(src->mNumVertices);

        for (auto i = 0u; i < src->mNumVertices; ++i)
        {
            auto position = &(src->mVertices[i]);
            auto normal = &(src->mNormals[i]);
            auto uv = (src->HasTextureCoords(0)) ? &(src->mTextureCoords[0][i]) : &zero3D;
            auto tangent = (src->HasTangentsAndBitangents()) ? &(src->mTangents[i]) : &zero3D;
            auto color = (src->HasVertexColors(0)) ? &(src->mColors[0][i]) : &zeroColor;


            // ���]�I�v�V��������������UV�𔽓]������
            if (inverseU)
            {
                uv->x = 1 - uv->x;
            }
            if (inverseV)
            {
                uv->y = 1 - uv->y;
            }

            Vertex3D vertex = {};
            vertex.Position = DirectX::XMFLOAT3(position->x, position->y, position->z);
            vertex.Normal = DirectX::XMFLOAT3(normal->x, normal->y, normal->z);
            vertex.UV = DirectX::XMFLOAT2(uv->x, uv->y);
            vertex.Tangent = DirectX::XMFLOAT3(tangent->x, tangent->y, tangent->z);
            vertex.Color = DirectX::XMFLOAT4(color->r, color->g, color->b, color->a);

            minX = std::min(minX, vertex.Position.x);
            minY = std::min(minY, vertex.Position.y);
            minZ = std::min(minZ, vertex.Position.z);

            maxX = std::max(maxX, vertex.Position.x);
            maxY = std::max(maxY, vertex.Position.y);
            maxZ = std::max(maxZ, vertex.Position.z);

            dst.Vertices[i] = vertex;
        }

        dst.Indices.resize(src->mNumFaces * 3);

        for (auto i = 0u; i < src->mNumFaces; ++i)
        {
            const auto &face = src->mFaces[i];

            dst.Indices[i * 3 + 0] = face.mIndices[0];
            dst.Indices[i * 3 + 1] = face.mIndices[1];
            dst.Indices[i * 3 + 2] = face.mIndices[2];
        }

        /*for (unsigned int i = 0; i < src->mNumVertices; ++i) {
            auto uv = (src->HasTextureCoords(0)) ? &(src->mTextureCoords[0][i]) : &zero3D;
            Vertex3D v{};
            v.Position = { src->mVertices[i].x, src->mVertices[i].y, src->mVertices[i].z };
            v.Normal = { src->mNormals[i].x, src->mNormals[i].y, src->mNormals[i].z };
            v.UV = { inverseU ? 1 - uv->x : uv->x, inverseV ? 1 - uv->y : uv->y };
            dst.Vertices.push_back(v);
        }
        for (unsigned int i = 0; i < src->mNumFaces; ++i) {
            const auto &f = src->mFaces[i];
            if (f.mNumIndices == 3) {
                dst.Indices.push_back(f.mIndices[0]);
                dst.Indices.push_back(f.mIndices[1]);
                dst.Indices.push_back(f.mIndices[2]);
            }
        }*/
    }

    void MeshLoader::NormalizeScale(Mesh &mesh) {

        float centerX;
        float centerY;
        float centerZ;
        float sizeX;
        float sizeY;
        float sizeZ;
        float maxDimension;
        float targetSize;
        float scaleFactor;

        centerX = (minX + maxX) / 2.0f;
        centerY = (minY + maxY) / 2.0f;
        centerZ = (minZ + maxZ) / 2.0f;
        sizeX = maxX - minX;
        sizeY = maxY - minY;
        sizeZ = maxZ - minZ;
        maxDimension = std::max({ sizeX, sizeY, sizeZ });
        targetSize = 1.0f; // �ڕW�̑傫��
        scaleFactor = targetSize / maxDimension;// �ڕW�̑傫���ɍ��킹�邽�߂̃X�P�[�� return;
        // �X�P�[����K�p

        for (auto &vertex : mesh.Vertices)
        {

            vertex.Position.x -= centerX;
            vertex.Position.y -= centerY;
            vertex.Position.z -= centerZ;
        }
        for (auto &vertex : mesh.Vertices) {

            vertex.Position.x *= scaleFactor;
            vertex.Position.y *= scaleFactor;
            vertex.Position.z *= scaleFactor;

        }

    }

}
