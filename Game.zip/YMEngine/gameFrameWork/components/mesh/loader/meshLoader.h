#pragma once

namespace ym {
    class Object;

    namespace mesh {
        class Mesh;
        class MeshInstance;

        class MeshLoader {
        public:
            //static std::shared_ptr<MeshInstance> LoadMesh(const std::string &filePath);
            static void LoadMeshHierarchy(std::shared_ptr<Object> parent, const std::string &filePath);

        private:
            static void LoadMesh(Mesh &dst, const struct aiMesh *src, bool inverseU, bool inverseV);
            static void NormalizeScale(Mesh &mesh);
             private:
			static float minX, minY, minZ;
			static float maxX, maxY, maxZ;
        };
    }
}