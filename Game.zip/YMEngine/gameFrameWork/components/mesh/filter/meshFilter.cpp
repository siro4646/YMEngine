#include "meshFilter.h"
#include "../instance/meshInstance.h"
#include "../renderer/meshRenderer.h"

#include "Renderer/renderer.h"
#include "device/device.h"
#include "commandList/commandList.h"
#include "descriptorSet/DescriptorSet.h"
#include "buffer/buffer.h"
#include "bufferView/bufferView.h"

#include "camera/camera.h"
#include "camera/cameraManager.h"

#include "../renderer/meshRenderer.h"

namespace ym
{
	namespace mesh
	{
		void MeshFilter::Init()
		{
			// ���������̏����i�K�v�ɉ����āj
			renderer_ = Renderer::Instance();
			if (renderer_)
			{
				device_ = renderer_->GetDevice();
				cmdList_ = renderer_->GetGraphicCommandList();
			}
			CreateConstantBuffer();
			pCamera_ = CameraManager::Instance().GetMainCamera();
		}

		void MeshFilter::Update()
		{
			UpdateMatrix();
		}

		void MeshFilter::Uninit()
		{
			meshInstance_.reset();
			vertexBuffer_.reset();
			vbView_.reset();
			indexBuffer_.reset();
			ibView_.reset();
			renderer_ = nullptr;
			device_ = nullptr;
			cmdList_ = nullptr;

			constantBuffer_.reset();
			constBufferView_.reset();
			pMatrix_ = nullptr;
			pCamera_ = nullptr;
		}

		void MeshFilter::SetMeshInstance(std::shared_ptr<MeshInstance> instance)
		{
			meshInstance_ = instance;
			CreateVertexBuffer();
			CreateIndexBuffer();

			//�ύX������MehsRenderer�ɒʒm
			auto meshRenderer = GetComponent<MeshRenderer>();
			if (meshRenderer)
			{
				//MeshRenderer�Ɏ�����n��
				meshRenderer->SetMeshFilter(this);
			}
		}

		std::shared_ptr<MeshInstance> MeshFilter::GetMeshInstance() const
		{
			return meshInstance_;
		}

		void MeshFilter::DrawImguiBody()
		{
			if (meshInstance_)
			{
				ImGui::Text("MeshInstance: %p", meshInstance_.get());

				const auto &mesh = meshInstance_->GetMesh();

				// ���_���\��
				ImGui::Text("Vertex Count: %zu", mesh.Vertices.size());
				//�o�b�t�@�̓��e��\��
				ImGui::Text("Vertex Buffer Size: %zu bytes", vertexBuffer_ ? vertexBuffer_->GetSize() : 0);
				ImGui::Text("Vertex Stride: %zu bytes", vertexBuffer_ ? vertexBuffer_->GetStride() : 0);
				//�r���[�̏���\��				
				ImGui::Text("Vertex Buffer View Offset: %zu", vbView_ ? vbView_->GetBufferOffset() : 0);

				if (ImGui::TreeNode("Vertices"))
				{
					for (size_t i = 0; i < mesh.Vertices.size(); ++i)
					{
						const auto &v = mesh.Vertices[i];
						ImGui::Text("[%zu] Pos(%.2f, %.2f, %.2f), Normal(%.2f, %.2f, %.2f), UV(%.2f, %.2f)",
							i,
							v.Position.x, v.Position.y, v.Position.z,
							v.Normal.x, v.Normal.y, v.Normal.z,
							v.UV.x, v.UV.y);

						// �\�����𐧌��i�d���̂Łj
						if (i >= 10)
						{
							ImGui::TextDisabled("...and more");
							break;
						}
					}
					
					ImGui::TreePop();
				}

				// �C���f�b�N�X���\��
				ImGui::Text("Index Count: %zu", mesh.Indices.size());
				//�o�b�t�@�̓��e��\��
				ImGui::Text("Index Buffer Size: %zu bytes", indexBuffer_ ? indexBuffer_->GetSize() : 0);
				ImGui::Text("Index Stride: %zu bytes", indexBuffer_ ? indexBuffer_->GetStride() : 0);
				//�r���[�̏���\��
				ImGui::Text("Index Buffer View Offset: %zu", ibView_ ? ibView_->GetBufferOffset() : 0);


				if (ImGui::TreeNode("Indices"))
				{
					for (size_t i = 0; i < mesh.Indices.size(); i += 3)
					{
						if (i + 2 < mesh.Indices.size())
						{
							ImGui::Text("[%zu-%zu] %u, %u, %u", i, i + 2,
								mesh.Indices[i], mesh.Indices[i + 1], mesh.Indices[i + 2]);
						}
						else
						{
							ImGui::Text("[%zu] %u", i, mesh.Indices[i]);
						}

						if (i >= 30) // �ő�10�ʂ����\��
						{
							ImGui::TextDisabled("...and more");
							break;
						}
					}
					ImGui::TreePop();
				}
			}
			else
			{
				ImGui::TextDisabled("No MeshInstance assigned");
			}
		}

		void MeshFilter::ApplyBuffers()
		{
			auto cmdList = cmdList_->GetCommandList();

			cmdList->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
			if (vertexBuffer_)
			{
				cmdList->IASetVertexBuffers(0, 1, &vbView_->GetView());
			}
			else
			{
				ym::DebugLog("Vertex buffer is not initialized.");
			}
			if (indexBuffer_)
			{
				cmdList->IASetIndexBuffer(&ibView_->GetView());
			}
			else
			{
				ym::DebugLog("Index buffer is not initialized.");
			}
		}

		void MeshFilter::ApplyConstantBuffers(DescriptorSet *ds)
		{
			ds->SetVsCbv(0, constBufferView_->GetDescInfo().cpuHandle);
			ds->SetVsCbv(1, pCamera_->GetDescriptorHandle());
		}

		void MeshFilter::CreateVertexBuffer()
		{
			auto vertexSize = sizeof(Vertex3D);
			auto bufferSize = meshInstance_->GetMesh().Vertices.size() * vertexSize;
			vertexBuffer_ = std::make_shared<Buffer>();
			vertexBuffer_->Init(device_, bufferSize, vertexSize, BufferUsage::VertexBuffer, false, false);
			vbView_ = std::make_shared<VertexBufferView>();
			vbView_->Init(device_, vertexBuffer_.get());
			vertexBuffer_->UpdateBuffer(device_, cmdList_, meshInstance_->GetMesh().Vertices.data(), bufferSize);
		}

		void MeshFilter::CreateIndexBuffer()
		{
			auto indexSize = sizeof(u32);
			auto bufferSize = meshInstance_->GetMesh().Indices.size() * indexSize;
			indexBuffer_ = std::make_shared<Buffer>();
			indexBuffer_->Init(device_, bufferSize, indexSize, BufferUsage::IndexBuffer, false, false);
			ibView_ = std::make_shared<IndexBufferView>();
			ibView_->Init(device_, indexBuffer_.get());
			indexBuffer_->UpdateBuffer(device_, cmdList_, meshInstance_->GetMesh().Indices.data(), bufferSize);
		}

		void MeshFilter::CreateConstantBuffer()
		{
			constantBuffer_ = std::make_shared<Buffer>();
			constantBuffer_.get()->Init(pDevice_.get(), sizeof(*pMatrix_), sizeof(XMMATRIX), BufferUsage::ConstantBuffer, true, false);
			constBufferView_ = std::make_shared<ConstantBufferView>();
			constBufferView_.get()->Init(pDevice_.get(), constantBuffer_.get());

			pMatrix_ = (XMMATRIX *)constantBuffer_.get()->Map();
			if (!pMatrix_)
			{
				assert(0 && "�萔�o�b�t�@�̃}�b�v�Ɏ��s");
			}
			*pMatrix_ = XMMatrixIdentity();
			UpdateMatrix();
		}

		void MeshFilter::UpdateMatrix()
		{
			(*pMatrix_) = object->worldTransform.GetMatrix();
		}

	}
}