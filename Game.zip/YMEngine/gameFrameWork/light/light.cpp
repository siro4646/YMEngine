#include "light.h"
#include "C:\Users\yusuk\Desktop\study\dx12\YMEngine\pch.h"

namespace ym
{
}