#include "ParticleSystem.h"

namespace ym
{
	void ParticleSystem::Init()
	{
	
	}
	void ParticleSystem::FixedUpdate()
	{
		
	}

	void ParticleSystem::Update()
	{
	}

	void ParticleSystem::Draw()
	{
	
	}

	void ParticleSystem::Uninit()
	{
	}

	void ParticleSystem::CreateBuffer()
	{
	}


}

